// Vite minimal config
export default {
  build: { outDir: "dist" },
  server: { host: true }
};
