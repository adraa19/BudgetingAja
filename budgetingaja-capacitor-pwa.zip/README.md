# BudgetingAja — Capacitor + Vite Starter

Ini proyek pembungkus Capacitor untuk HTML Anda agar bisa dijalankan di Android/iOS.

## Prasyarat
- Node.js & npm
- Android Studio (untuk Android)
- Xcode + akun Apple Developer (untuk iOS; butuh Mac)

## Cara Pakai
1. Buka terminal di folder ini, lalu install deps:
   ```bash
   npm install
   ```

2. Inisialisasi Capacitor (sekali saja):
   ```bash
   npx cap init "BudgetingAja" "com.yourname.budgetingaja"
   ```
   Saat diminta `webDir`, pastikan `dist`.

   > Atau gunakan default yang sudah kami siapkan di `capacitor.config.ts`
   > (ubah `appId` & `appName` sesuai kebutuhan).

3. Build web & tambahkan platform:
   ```bash
   npm run build
   npx cap add android
   npx cap add ios
   npx cap copy
   npx cap sync
   ```

4. Buka di IDE:
   ```bash
   npx cap open android   # Buka Android Studio
   npx cap open ios       # Buka Xcode
   ```

5. Jalankan di emulator atau device.

## Mengganti/menambah file
- Edit `index.html` (berasal dari file Anda). Pastikan semua asset (CSS/JS/gambar) tersedia lokal jika ingin offline penuh.
- Setelah perubahan, jalankan `npm run build` lalu `npx cap copy`/`npx cap sync` lagi.

## Ikon & Splash
- Tambahkan aset di `resources/` atau set manual via Android Studio/Xcode.

## Plugin (contoh Filesystem untuk ekspor/impor):
```bash
npm install @capacitor/filesystem
```
Lalu gunakan sesuai dokumentasi Capacitor.

---

Dibuat otomatis dari HTML Anda. Semoga membantu!

## Mode PWA (Installable di Android)
- File `manifest.webmanifest` dan `service-worker.js` sudah disiapkan.
- Jalankan dev server: `npm run dev`, lalu buka dari **Chrome Android**, pilih **Add to Home Screen**.
- Untuk build production PWA: `npm run build`. Pastikan file `service-worker.js` dan `manifest.webmanifest` ikut disajikan dari root `dist`/server Anda.
- Ganti ikon di `resources/icons/` dengan ikon aplikasi Anda (PNG 192 & 512).
